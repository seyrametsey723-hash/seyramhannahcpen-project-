# CPEN 208 Combined Project 1 + Project 2

This repository implements the two supplied CPEN 208 assignments:

- **Project 1:** PostgreSQL relational database + Next.js 14 login/register/dashboard.
- **Project 2:** API/web service implementing the Project 1 functions.

The assignments require student personal information, fee payments, course enrollment, lecturer-to-course assignment, lecturer-to-TA assignment, sample inserts, and a database function returning outstanding fees as JSON. They also require the source code, database scripts, database backup, GitHub repository, and a report. See the supplied assignment PDFs for the original requirements.

## 1. Technology

- PostgreSQL
- Next.js 14 App Router
- React 18
- TypeScript
- Node.js 18.17+
- `pg` for PostgreSQL access
- `bcryptjs` for password hashing
- `jose` for signed login sessions
- Plain CSS with a warm, natural visual design

## 2. Data source

`swe_names.xlsx` supplied for the assignment contains **70 students** with two columns: Student ID and Name. Those 70 records are inserted into `cpen208.students`.

Student emails are generated as `<student_id>@st.ug.edu.gh` because the spreadsheet contains no email column. This is an explicit project assumption.

## 3. Database design

Schema: `cpen208`

Main tables:

1. `students` — student personal information.
2. `lecturers` — lecturer information.
3. `teaching_assistants` — identifies students serving as TAs.
4. `courses` — course information.
5. `course_enrollments` — student/course many-to-many relationship.
6. `course_lecturers` — lecturer/course assignment.
7. `course_tas` — TA/course assignment.
8. `fee_invoices` — amount each student is required to pay.
9. `fee_payments` — payments made against invoices.
10. `app_users` — credentials for the web application's login/register feature.

The `get_outstanding_fees()` PostgreSQL function returns a JSONB array containing each student's ID, name, amount due, amount paid, and outstanding balance.

## 4. Install and run

### Step 1 — Install PostgreSQL

Make sure PostgreSQL is installed and the PostgreSQL service is running.

### Step 2 — Create the database

Open `psql` or pgAdmin and create the database:

```sql
CREATE DATABASE cpen208;
```

Then connect to `cpen208`.

Run these scripts in this order:

```text
db/01_schema.sql
db/02_seed.sql
```

If using psql:

```bash
psql -U postgres -d cpen208 -f db/01_schema.sql
psql -U postgres -d cpen208 -f db/02_seed.sql
```

### Step 3 — Verify the database

```sql
SELECT COUNT(*) FROM cpen208.students;
SELECT cpen208.get_outstanding_fees();
```

The student count should be **70**.

### Step 4 — Create the Next.js project environment

From this folder:

```bash
npm install
```

Copy `.env.example` to `.env.local` and set:

```env
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/cpen208
JWT_SECRET=replace-with-a-long-random-secret
```

Use the PostgreSQL username/password that actually exists on your computer.

### Step 5 — Start the application

```bash
npm run dev
```

Open:

```text
http://localhost:3000
```

Register a user, log in, and use the dashboard.

## 5. API endpoints

All API routes are Next.js Route Handlers, so the application itself provides the required web service.

### Student information

```http
GET /api/students
```

Create a student:

```http
POST /api/students
Content-Type: application/json

{
  "student_id": "22499999",
  "full_name": "Example Student",
  "email": "22499999@st.ug.edu.gh"
}
```

### Courses

```http
GET /api/courses
```

### Enrollments

```http
GET /api/enrollments
```

Create enrollment:

```http
POST /api/enrollments
Content-Type: application/json

{
  "student_id": "22384451",
  "course_id": "CPEN208"
}
```

### Fees

```http
GET /api/fees
```

Record a payment:

```http
POST /api/fees
Content-Type: application/json

{
  "student_id": "22384451",
  "invoice_id": 1,
  "amount_paid": 250,
  "reference": "PAY-001"
}
```

### Outstanding fees

```http
GET /api/fees/outstanding
```

This endpoint directly calls the required PostgreSQL function:

```sql
SELECT cpen208.get_outstanding_fees();
```

### Lecturer and TA assignments

```http
GET /api/assignments
```

Assign a lecturer:

```http
POST /api/assignments
Content-Type: application/json

{
  "course_id": "CPEN208",
  "lecturer_id": 1
}
```

Assign a TA:

```http
POST /api/assignments
Content-Type: application/json

{
  "course_id": "CPEN208",
  "ta_id": 1
}
```

## 6. Database backup

After creating and seeding the database, make a backup with:

```bash
pg_dump -U postgres -d cpen208 -F c -f cpen208_backup.dump
```

For a readable SQL backup:

```bash
pg_dump -U postgres -d cpen208 -f cpen208_backup.sql
```

Put the backup file in the GitHub project before submission.

## 7. GitHub submission

```bash
git init
git add .
git commit -m "Complete CPEN 208 Project 1 and Project 2"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Do **not** commit `.env.local` or real passwords.

## 8. Submission checklist

- [ ] Next.js 14 source code
- [ ] PostgreSQL schema script
- [ ] PostgreSQL seed/insert script
- [ ] Database backup
- [ ] API/web service source code
- [ ] Report PDF
- [ ] GitHub repository URL

## 9. Design choice

The UI uses warm brown, terracotta, cream and soft orange tones. The main font is a natural serif stack (`Georgia`, `Times New Roman`) so the interface has a warm academic feel without requiring an external font download.
