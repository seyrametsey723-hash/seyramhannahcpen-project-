"use client";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
  const [error,setError]=useState(""); const router=useRouter();

  async function submit(e:FormEvent){
    e.preventDefault(); setError("");
    const res=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,password})});
    const data=await res.json();
    if(!res.ok){setError(data.error||"Login failed");return;}
    router.push("/dashboard"); router.refresh();
  }
  return <main className="hero"><div className="card auth">
    <h1>CPEN 208 Portal</h1><p className="muted">Software Engineering Student Management System</p>
    {error && <div className="error">{error}</div>}
    <form onSubmit={submit}>
      <label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
      <label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
      <div className="actions"><button className="btn">Login</button><a className="btn secondary" href="/register">Register</a></div>
    </form>
  </div></main>;
}
