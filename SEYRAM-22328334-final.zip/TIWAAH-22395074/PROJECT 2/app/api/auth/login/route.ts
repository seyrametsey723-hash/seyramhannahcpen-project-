import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { pool } from "../../../../lib/db";
import { createSession } from "../../../../lib/auth";

export async function POST(req: Request) {
  try {
    const {email,password}=await req.json();
    const result=await pool.query("SELECT name,password_hash FROM app_users WHERE email=$1",[String(email).toLowerCase()]);
    if(!result.rowCount || !(await bcrypt.compare(password,result.rows[0].password_hash)))
      return NextResponse.json({error:"Invalid email or password."},{status:401});
    await createSession({name:result.rows[0].name,email:String(email).toLowerCase()});
    return NextResponse.json({ok:true});
  } catch { return NextResponse.json({error:"Could not log in. Check your database connection."},{status:500}); }
}
