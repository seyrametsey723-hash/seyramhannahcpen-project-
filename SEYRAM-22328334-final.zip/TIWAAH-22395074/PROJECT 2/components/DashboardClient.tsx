"use client";
import { useEffect, useState } from "react";

type Student={student_id:string;full_name:string;email:string;department:string;account_status:string};
type Lecturer={lecturer_id:number;full_name:string;email:string;department:string};
type Summary={student_id:string;student_name:string;amount_due:string;amount_paid:string;outstanding:string};
type Payment={payment_id:number;student_id:string;full_name:string;invoice_id:number;amount_paid:string;payment_date:string;reference:string};
type Course={course_id:string;course_name:string;credit_hours:number;semester:string;academic_year:string};
type Enrollment={enrollment_id:number;student_id:string;full_name:string;course_id:string;course_name:string;status:string;enrolled_on:string};

async function api(url:string, method:string, body?:object){
  const res = await fetch(url, {
    method,
    headers: body ? {"Content-Type":"application/json"} : undefined,
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || "Request failed.");
  return data;
}

export default function DashboardClient({user}:{user:{name:string;email:string}}){
  const [students,setStudents]=useState<Student[]>([]);
  const [lecturers,setLecturers]=useState<Lecturer[]>([]);
  const [courses,setCourses]=useState<Course[]>([]);
  const [fees,setFees]=useState<Summary[]>([]);
  const [payments,setPayments]=useState<Payment[]>([]);
  const [enrollments,setEnrollments]=useState<Enrollment[]>([]);
  const [loading,setLoading]=useState(true);
  const [msg,setMsg]=useState<{type:"error"|"success";text:string}|null>(null);

  async function load(){
    setLoading(true);
    const [s,l,c,f,p,e]=await Promise.all([
      fetch("/api/students"), fetch("/api/lecturers"), fetch("/api/courses"),
      fetch("/api/fees/outstanding"), fetch("/api/fees?view=payments"), fetch("/api/enrollments")
    ]);
    setStudents(await s.json()); setLecturers(await l.json()); setCourses(await c.json());
    setFees(await f.json()); setPayments(await p.json()); setEnrollments(await e.json());
    setLoading(false);
  }
  useEffect(()=>{load()},[]);
  async function logout(){await fetch("/api/auth/logout",{method:"POST"}); location.href="/login";}

  async function run(action:()=>Promise<any>, successText:string){
    setMsg(null);
    try { await action(); setMsg({type:"success",text:successText}); await load(); }
    catch(err:any){ setMsg({type:"error",text:err.message}); }
  }

  return <>
  <header className="topbar"><div className="container topbar-inner">
    <div><strong>CPEN 208 Portal</strong><div className="small">Welcome, {user.name}</div></div>
    <nav className="nav">
      <a href="#students">Students</a><a href="#lecturers">Lecturers</a>
      <a href="#courses">Courses</a><a href="#enrollments">Enrollments</a><a href="#fees">Fees</a>
      <button className="btn secondary" onClick={logout}>Logout</button>
    </nav>
  </div></header>
  <main className="container">
    {msg && <div className={msg.type}>{msg.text}</div>}
    <div className="grid">
      <div className="stat">Students<strong>{students.length}</strong></div>
      <div className="stat">Lecturers<strong>{lecturers.length}</strong></div>
      <div className="stat">Outstanding students<strong>{fees.filter(x=>Number(x.outstanding)>0).length}</strong></div>
    </div>

    {/* STUDENTS */}
    <div className="card" id="students"><h2>Student personal information</h2>
      <form className="form-row" onSubmit={(e)=>{
        e.preventDefault();
        const form=e.currentTarget;
        const f=new FormData(form);
        run(()=>api("/api/students","POST",{
          student_id:f.get("student_id"), full_name:f.get("full_name"), email:f.get("email")
        }), "Student added.").then(()=>form.reset());
      }}>
        <div className="field"><label>Student ID</label><input name="student_id" required/></div>
        <div className="field"><label>Full name</label><input name="full_name" required/></div>
        <div className="field"><label>Email</label><input name="email" type="email" required/></div>
        <button className="btn" type="submit">Add student</button>
      </form>
      {loading?<p>Loading...</p>:<div className="table-wrap"><table><thead>
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Status</th><th></th></tr>
      </thead><tbody>
        {students.map(s=><tr key={s.student_id}>
          <td>{s.student_id}</td><td>{s.full_name}</td><td>{s.email}</td><td>{s.account_status}</td>
          <td><button className="btn danger small" onClick={()=>{
            if(confirm(`Remove student ${s.student_id}?`))
              run(()=>api("/api/students","DELETE",{student_id:s.student_id}), "Student removed.");
          }}>Remove</button></td>
        </tr>)}
      </tbody></table></div>}
    </div>

    {/* LECTURERS */}
    <div className="card" id="lecturers" style={{marginTop:24}}><h2>Lecturers</h2>
      <form className="form-row" onSubmit={(e)=>{
        e.preventDefault();
        const form=e.currentTarget;
        const f=new FormData(form);
        run(()=>api("/api/lecturers","POST",{
          full_name:f.get("full_name"), email:f.get("email"), department:f.get("department")
        }), "Lecturer added.").then(()=>form.reset());
      }}>
        <div className="field"><label>Full name</label><input name="full_name" required/></div>
        <div className="field"><label>Email</label><input name="email" type="email" required/></div>
        <div className="field"><label>Department</label><input name="department" placeholder="Computer Engineering"/></div>
        <button className="btn" type="submit">Add lecturer</button>
      </form>
      <div className="table-wrap"><table><thead>
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Department</th><th></th></tr>
      </thead><tbody>
        {lecturers.map(l=><tr key={l.lecturer_id}>
          <td>{l.lecturer_id}</td><td>{l.full_name}</td><td>{l.email}</td><td>{l.department}</td>
          <td><button className="btn danger small" onClick={()=>{
            if(confirm(`Remove lecturer ${l.full_name}?`))
              run(()=>api("/api/lecturers","DELETE",{lecturer_id:l.lecturer_id}), "Lecturer removed.");
          }}>Remove</button></td>
        </tr>)}
      </tbody></table></div>
    </div>

    {/* COURSES */}
    <div className="card" id="courses" style={{marginTop:24}}><h2>Courses</h2>
      <div className="table-wrap"><table><thead><tr><th>Code</th><th>Course</th><th>Credits</th><th>Semester</th></tr></thead><tbody>
      {courses.map(c=><tr key={c.course_id}><td>{c.course_id}</td><td>{c.course_name}</td><td>{c.credit_hours}</td><td>{c.semester}</td></tr>)}
      </tbody></table></div>
    </div>

    {/* ENROLLMENTS */}
    <div className="card" id="enrollments" style={{marginTop:24}}><h2>Course enrollments</h2>
      <form className="form-row" onSubmit={(e)=>{
        e.preventDefault();
        const form=e.currentTarget;
        const f=new FormData(form);
        run(()=>api("/api/enrollments","POST",{
          student_id:f.get("student_id"), course_id:f.get("course_id")
        }), "Enrollment added.").then(()=>form.reset());
      }}>
        <div className="field"><label>Student ID</label><input name="student_id" required/></div>
        <div className="field"><label>Course code</label><input name="course_id" required/></div>
        <button className="btn" type="submit">Enroll</button>
      </form>
      <div className="table-wrap"><table><thead>
        <tr><th>Student</th><th>Course</th><th>Status</th><th>Enrolled on</th><th></th></tr>
      </thead><tbody>
        {enrollments.map(en=><tr key={en.enrollment_id}>
          <td>{en.full_name}</td><td>{en.course_id} — {en.course_name}</td>
          <td>
            <select defaultValue={en.status} onChange={(e)=>
              run(()=>api("/api/enrollments","PATCH",{enrollment_id:en.enrollment_id, status:e.target.value}), "Enrollment updated.")
            }>
              <option>Enrolled</option><option>Dropped</option><option>Completed</option>
            </select>
          </td>
          <td>{en.enrolled_on}</td>
          <td><button className="btn danger small" onClick={()=>{
            if(confirm("Remove this enrollment?"))
              run(()=>api("/api/enrollments","DELETE",{enrollment_id:en.enrollment_id}), "Enrollment removed.");
          }}>Remove</button></td>
        </tr>)}
      </tbody></table></div>
    </div>

    {/* FEES */}
    <div className="card" id="fees" style={{marginTop:24}}><h2>Outstanding fees</h2>
      <div className="table-wrap"><table><thead><tr><th>Student</th><th>Due</th><th>Paid</th><th>Outstanding</th></tr></thead><tbody>
      {fees.map(f=><tr key={f.student_id}><td>{f.student_name}</td><td>GHS {Number(f.amount_due).toFixed(2)}</td><td>GHS {Number(f.amount_paid).toFixed(2)}</td><td><strong>GHS {Number(f.outstanding).toFixed(2)}</strong></td></tr>)}
      </tbody></table></div>

      <h2 style={{marginTop:28}}>Fee payments</h2>
      <form className="form-row" onSubmit={(e)=>{
        e.preventDefault();
        const form=e.currentTarget;
        const f=new FormData(form);
        run(()=>api("/api/fees","POST",{
          student_id:f.get("student_id"), invoice_id:Number(f.get("invoice_id")),
          amount_paid:Number(f.get("amount_paid")), reference:f.get("reference")
        }), "Payment recorded.").then(()=>form.reset());
      }}>
        <div className="field"><label>Student ID</label><input name="student_id" required/></div>
        <div className="field"><label>Invoice ID</label><input name="invoice_id" type="number" required/></div>
        <div className="field"><label>Amount paid (GHS)</label><input name="amount_paid" type="number" step="0.01" required/></div>
        <div className="field"><label>Reference</label><input name="reference" required/></div>
        <button className="btn" type="submit">Record payment</button>
      </form>
      <div className="table-wrap"><table><thead>
        <tr><th>Student</th><th>Invoice</th><th>Amount paid</th><th>Reference</th><th>Date</th><th></th></tr>
      </thead><tbody>
        {payments.map(p=><tr key={p.payment_id}>
          <td>{p.full_name}</td><td>{p.invoice_id}</td>
          <td>
            <input defaultValue={Number(p.amount_paid).toFixed(2)} style={{width:100}}
              onBlur={(e)=>{
  const val=Number(e.target.value);
  if(!val || val<=0){ setMsg({type:"error",text:"Amount paid must be greater than 0."}); e.target.value=Number(p.amount_paid).toFixed(2); return; }
  if(val!==Number(p.amount_paid))
    run(()=>api("/api/fees","PATCH",{payment_id:p.payment_id, amount_paid:val}), "Payment updated.");
}}/>
          </td>
          <td>
            <input defaultValue={p.reference} style={{width:120}}
              onBlur={(e)=>{
                if(e.target.value && e.target.value!==p.reference)
                  run(()=>api("/api/fees","PATCH",{payment_id:p.payment_id, reference:e.target.value}), "Payment updated.");
              }}/>
          </td>
          <td>{p.payment_date}</td>
          <td><button className="btn danger small" onClick={()=>{
            if(confirm("Delete this payment?"))
              run(()=>api("/api/fees","DELETE",{payment_id:p.payment_id}), "Payment deleted.");
          }}>Delete</button></td>
        </tr>)}
      </tbody></table></div>
    </div>
  </main></>;
}