import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { pool } from "../../../../lib/db";
import { createSession } from "../../../../lib/auth";

export async function POST(req: Request) {
  try {
    const { name, email, password } = await req.json();
    if (!name || !email || !password || password.length < 8)
      return NextResponse.json({error:"Name, email and an 8+ character password are required."},{status:400});
    const exists = await pool.query("SELECT 1 FROM app_users WHERE email=$1",[email.toLowerCase()]);
    if (exists.rowCount) return NextResponse.json({error:"Email already registered."},{status:409});
    const hash=await bcrypt.hash(password,12);
    await pool.query("INSERT INTO app_users(name,email,password_hash) VALUES($1,$2,$3)",[name,email.toLowerCase(),hash]);
    await createSession({name,email:email.toLowerCase()});
    return NextResponse.json({ok:true});
  } catch { return NextResponse.json({error:"Could not register. Check your database connection."},{status:500});
  }
}
