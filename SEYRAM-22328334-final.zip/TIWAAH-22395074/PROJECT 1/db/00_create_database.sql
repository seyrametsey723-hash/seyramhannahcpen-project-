-- Run this while connected to PostgreSQL's default postgres database.
-- Replace the database name if your lecturer requires another name.
CREATE DATABASE cpen208;
-- Then connect to cpen208 and run 01_schema.sql followed by 02_seed.sql.
