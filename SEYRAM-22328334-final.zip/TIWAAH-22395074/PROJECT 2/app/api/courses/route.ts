import { NextResponse } from "next/server";
import { pool } from "../../../lib/db";
export async function GET(){
 const {rows}=await pool.query("SELECT course_id,course_name,credit_hours,semester,academic_year FROM cpen208.courses ORDER BY course_id");
 return NextResponse.json(rows);
}
