import { NextResponse } from "next/server";
import { pool } from "../../../lib/db";

export async function GET() {
  const {rows}=await pool.query(`
    SELECT c.course_id,c.course_name,
           COALESCE(string_agg(DISTINCT l.full_name, ', '), 'None') AS lecturers,
           COALESCE(string_agg(DISTINCT s.full_name, ', '), 'None') AS teaching_assistants
    FROM cpen208.courses c
    LEFT JOIN cpen208.course_lecturers cl ON cl.course_id=c.course_id
    LEFT JOIN cpen208.lecturers l ON l.lecturer_id=cl.lecturer_id
    LEFT JOIN cpen208.course_tas ct ON ct.course_id=c.course_id
    LEFT JOIN cpen208.teaching_assistants ta ON ta.ta_id=ct.ta_id
    LEFT JOIN cpen208.students s ON s.student_id=ta.student_id
    GROUP BY c.course_id,c.course_name ORDER BY c.course_id`);
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  try {
    const {course_id, lecturer_id, ta_id}=await req.json();
    if(!course_id || (!lecturer_id && !ta_id))
      return NextResponse.json({error:"course_id and either lecturer_id or ta_id are required."},{status:400});
    if(lecturer_id){
      await pool.query(`INSERT INTO cpen208.course_lecturers(course_id,lecturer_id) VALUES($1,$2)`,[course_id,lecturer_id]);
    } else {
      await pool.query(`INSERT INTO cpen208.course_tas(course_id,ta_id) VALUES($1,$2)`,[course_id,ta_id]);
    }
    return NextResponse.json({ok:true},{status:201});
  } catch {
    return NextResponse.json({error:"Assignment failed. Check the course/staff ID or duplicate assignment."},{status:409});
  }
}
