SET search_path TO cpen208, public;

INSERT INTO students(student_id, full_name, email, department, account_status) VALUES
('22384451', 'Abu Neaquittae Golda', '22384451@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22357814', 'Adzasa Stephen Yaw', '22357814@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22375367', 'Afia Beaa Osei-Safo', '22375367@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22397756', 'Agbemavi Ryan', '22397756@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22369321', 'Agormeda Nathaniel Tetteh', '22369321@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22301848', 'Ahmad Mohammed Sahih Kayelgu', '22301848@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22339520', 'Amprofi Yaa Obeng', '22339520@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22333597', 'Asante Esme Lilian', '22333597@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22268986', 'Asante Gabriel Kwaku', '22268986@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22381577', 'Botchway Daniel', '22381577@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22315830', 'Brian Assibey-Yeboah', '22315830@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22388189', 'Caleb Mensah', '22388189@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22393520', 'Cyril Desmond Ofori', '22393520@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22312110', 'David Kwame Odoi-Anim', '22312110@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22300896', 'Doe Collins Kweku', '22300896@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22397491', 'Douglas Kwaw Adjei', '22397491@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22387715', 'Dzidzor Apu Apawudza', '22387715@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22382302', 'Edward Kakra Ankrah', '22382302@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22379061', 'Emmanuel Akotuah Osae', '22379061@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22368809', 'Emmanuel Dery', '22368809@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22370498', 'Ethan Edric Kweku Nartey', '22370498@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22382425', 'Gilbert Akwasi Sarkodie Yeboah', '22382425@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22396551', 'Jerrold Xornam Kyekye', '22396551@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22398562', 'Joseph Amankwah', '22398562@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22398596', 'Joshua Appiah', '22398596@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22385323', 'Jude Gyampoh Addo', '22385323@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22303421', 'Kemausuor Winambe Tetteh-Kumah', '22303421@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22407033', 'Kenzi Segbefia', '22407033@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22299189', 'Kessey Ntiako David', '22299189@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22407837', 'Kingsley Caldicock Quartey', '22407837@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22412615', 'Kofi Boateng Oware-Tano', '22412615@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22411009', 'Kwaku Aninkorah Barimah', '22411009@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22382547', 'Kwame Ayeh Obeng', '22382547@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22373317', 'Kwamena Kesse Quaicoe', '22373317@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22339058', 'Maame Abena Amihere Ahu', '22339058@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22302628', 'Maame Araba Grant-Aidoo', '22302628@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22396566', 'Manford Kelvin Oppong', '22396566@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22325819', 'Nana Adwoa Dansowaah Odoom', '22325819@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22344703', 'Nana Anokye', '22344703@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22306910', 'Newlove Yeboaah Kwarfo', '22306910@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22385472', 'Obeng Ernest Antwi', '22385472@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22399214', 'Obeng Ruth', '22399214@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22263126', 'Owusu Koranteng Yaw Poku', '22263126@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22373463', 'Owusu Nana Boadiwaa', '22373463@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22381702', 'Paula Akosua Asiedua Frimpong', '22381702@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22387846', 'Quaicoo Emile', '22387846@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22263922', 'Romel Alvin Nii Lartey Lartey', '22263922@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22401641', 'Sandra Naa Adaku Mettle', '22401641@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22403781', 'Sekyere Kofi Bempong', '22403781@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22304260', 'Tetteh Christian Edward Nii Mantey', '22304260@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22304013', 'Tietaah Sonnu', '22304013@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22302188', 'Van Jerry Quansah', '22302188@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22299949', 'William Enchill', '22299949@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22415339', 'Kelvin Kwesi Saah', '22415339@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22328334', 'Etsey Hannah Seyram', '22328334@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22412982', 'Adu Mini', '22412982@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22321110', 'Gideon Nana Osei Amofa', '22321110@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22306021', 'Paul Badu Amponsah', '22306021@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22385391', 'Najiib Abdul-Majeed Stephen', '22385391@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22394866', 'Joshua Kwame Asirifi', '22394866@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22382601', 'Eklou Juliet', '22382601@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22271867', 'De-Andra Rebecca Ayebo', '22271867@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('224018189', 'Mas''ud Nasir', '224018189@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22407018', 'Daniel Dwomoh Frimpong', '22407018@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22376708', 'Adjei Priscilla', '22376708@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22377537', 'Reuben Adomako', '22377537@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22400543', 'Ocansey Frederick', '22400543@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22402666', 'Dogbatse Darlington', '22402666@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22416112', 'Troy Thomas', '22416112@st.ug.edu.gh', 'Computer Engineering', 'Active'),
('22395074', 'Lydia Tiwaah', '22395074@st.ug.edu.gh', 'Computer Engineering', 'Active');

INSERT INTO lecturers(full_name,email) VALUES
('Dr. Kwame Mensah','kwame.mensah@ug.edu.gh'),
('Dr. Ama Owusu','ama.owusu@ug.edu.gh'),
('Dr. Kofi Boateng','kofi.boateng@ug.edu.gh'),
('Dr. Efua Asante','efua.asante@ug.edu.gh');

INSERT INTO teaching_assistants(student_id, role) VALUES
('22384451', 'TA'),
('22357814', 'TA'),
('22375367', 'TA'),
('22397756', 'TA'),
('22369321', 'TA'),
('22301848', 'TA'),
('22339520', 'TA'),
('22333597', 'TA'),
('22268986', 'TA'),
('22381577', 'TA'),
('22315830', 'TA'),
('22388189', 'TA');

INSERT INTO courses(course_id, course_name, credit_hours, semester, academic_year) VALUES
('CPEN208','Introduction to Software Engineering',3,'First Semester','2025/2026'),
('CPEN204','Data Structures and Algorithms',3,'First Semester','2025/2026'),
('CPEN206','Computer Architecture',3,'First Semester','2025/2026'),
('STAT212','Statistics for Engineers',3,'First Semester','2025/2026'),
('MATH222','Linear Algebra',3,'First Semester','2025/2026'),
('EEEN206','Circuit Theory',3,'First Semester','2025/2026');

INSERT INTO course_lecturers(course_id, lecturer_id) VALUES
('CPEN208',1),('CPEN204',2),('CPEN206',3),('STAT212',4),('MATH222',1),('EEEN206',2);

INSERT INTO course_tas(course_id, ta_id) VALUES
('CPEN208',1),('CPEN208',2),('CPEN204',3),('CPEN206',4),('STAT212',5),
('MATH222',6),('EEEN206',7),('CPEN204',8),('CPEN206',9),('STAT212',10);

-- Enrol every student in the core CPEN208 course; the first 20 also take the other sample courses.
INSERT INTO course_enrollments(student_id,course_id)
SELECT student_id,'CPEN208' FROM students;
INSERT INTO course_enrollments(student_id,course_id)
SELECT student_id,'CPEN204' FROM students WHERE student_id IN (SELECT student_id FROM students ORDER BY student_id LIMIT 20);
INSERT INTO course_enrollments(student_id,course_id)
SELECT student_id,'CPEN206' FROM students WHERE student_id IN (SELECT student_id FROM students ORDER BY student_id LIMIT 20);

-- Sample fee invoices for all students.
INSERT INTO fee_invoices(student_id,academic_year,semester,amount_due,due_date)
SELECT student_id,'2025/2026','First Semester',5000.00,'2025-11-30'
FROM students;

-- Payments: first 20 students pay GHS 3500, next 20 pay GHS 5000, others pay GHS 2000.
INSERT INTO fee_payments(student_id,invoice_id,amount_paid,payment_date,reference)
SELECT s.student_id, fi.invoice_id,
       CASE
         WHEN row_number() OVER (ORDER BY s.student_id) <= 20 THEN 3500.00
         WHEN row_number() OVER (ORDER BY s.student_id) <= 40 THEN 5000.00
         ELSE 2000.00
       END,
       '2025-10-15',
       'CPEN208-' || s.student_id
FROM students s
JOIN fee_invoices fi ON fi.student_id=s.student_id;

-- Check the required JSON function:
-- SELECT get_outstanding_fees();
